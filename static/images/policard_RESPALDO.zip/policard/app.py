from flask import Flask, render_template, request, flash, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_wtf import FlaskForm
from wtforms import StringField, IntegerField, SelectField
from wtforms.validators import DataRequired, NumberRange

app = Flask(__name__)
app.config['SECRET_KEY'] = 'policard2024secret'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///policard.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class Tarjeta(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(100), nullable=False)
    banco = db.Column(db.String(50), nullable=False)
    tipo = db.Column(db.String(50), nullable=False)
    cat = db.Column(db.Float, nullable=False)
    anualidad = db.Column(db.Float, nullable=False)
    edad_minima = db.Column(db.Integer, nullable=False)
    beneficios = db.Column(db.Text)

class BusquedaForm(FlaskForm):
    edad = IntegerField('Edad', validators=[DataRequired(), NumberRange(min=18, max=100)])
    tipo = SelectField('Tipo', choices=[('estudiante', 'Estudiante'), ('joven', 'Joven'), ('clasica', 'Clásica')])

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/tarjetas')
def tarjetas():
    todas_tarjetas = Tarjeta.query.all()
    return render_template('tarjetas.html', tarjetas=todas_tarjetas)

@app.route('/buscar', methods=['GET', 'POST'])
def buscar():
    form = BusquedaForm()
    resultados = []
    if form.validate_on_submit():
        edad = form.edad.data
        tipo = form.tipo.data
        resultados = Tarjeta.query.filter(Tarjeta.edad_minima <= edad, Tarjeta.tipo == tipo).all()
        if resultados:
            flash(f'¡Encontramos {len(resultados)} tarjeta(s) para ti!', 'success')
        else:
            flash('No encontramos tarjetas. Intenta con otros filtros.', 'warning')
    return render_template('buscar.html', form=form, resultados=resultados)

@app.route('/educacion')
def educacion():
    return render_template('educacion.html')

@app.route('/calculadora')
def calculadora():
    return render_template('calculadora.html')

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)